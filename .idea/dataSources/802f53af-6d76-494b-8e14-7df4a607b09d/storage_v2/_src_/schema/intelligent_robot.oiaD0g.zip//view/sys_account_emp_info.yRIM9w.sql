create view sys_account_emp_info as
  select `a`.`ACCOUNT_CODE`        AS `ACCOUNT_CODE`,
         `a`.`CTIPHONE`            AS `CTIPHONE`,
         `a`.`AGENT_ID`            AS `AGENT_ID`,
         `b`.`NAME`                AS `emp_name`,
         `b`.`ORG_CODE`            AS `ORG_CODE`,
         `a`.`SKILL_GROUP_CODE`    AS `SKILL_GROUP_CODE`,
         `a`.`BUSINESS_GROUP_CODE` AS `BUSINESS_GROUP_CODE`,
         `a`.`OPERATOR_TYPE_CODE`  AS `OPERATOR_TYPE_CODE`,
         `c`.`VALUE`               AS `value`
  from ((`intelligent_robot`.`sys_account_info` `a` left join `intelligent_robot`.`emp_base_info` `b` on ((
    `a`.`EMP_CODE` = `b`.`CODE`))) left join `intelligent_robot`.`sys_dictionary_info` `c` on ((
    (`a`.`BUSINESS_GROUP_CODE` = `c`.`CODE`) and (`c`.`CODE_PATH` = 'root/BusinessPara/UOMP/BusinessGroup'))));

