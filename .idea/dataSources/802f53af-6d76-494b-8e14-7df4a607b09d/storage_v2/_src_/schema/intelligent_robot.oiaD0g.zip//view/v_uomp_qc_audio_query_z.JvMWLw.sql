create view v_uomp_qc_audio_query_z as
  select `a`.`CUST_NAME`                                         AS `CUST_NAME`,
         `a`.`CUST_PHONE`                                        AS `CUST_PHONE`,
         `a`.`ROOM_NO`                                           AS `unique_serial_no`,
         `a`.`ROOM_NO`                                           AS `param`,
         `b`.`BEGIN_TIME`                                        AS `call_date`,
         `b`.`END_TIME`                                          AS `answer_date`,
         `b`.`ACCOUNT_CODE`                                      AS `parter_code`,
         `a`.`CHANNEL_NO`                                        AS `CHANNEL_NO`,
         `b`.`SATISFACTION`                                      AS `SATISFACTION`,
         `b`.`MESSAGE_NUM`                                       AS `MESSAGE_NUM`,
         timestampdiff(SECOND, `b`.`BEGIN_TIME`, `b`.`END_TIME`) AS `talk_seconds`
  from (`intelligent_robot`.`ochat_log_queue_info` `a` join `intelligent_robot`.`ochat_log_room` `b`)
  where ((`a`.`ROOM_NO` = `b`.`ROOM_NO`) and (`a`.`ROOM_NO` is not null) and (`b`.`END_TIME` is not null) and
         (`b`.`ACCOUNT_CODE` is not null) and
         (not(`a`.`ROOM_NO` in (select `intelligent_robot`.`uomp_qc_task_record`.`UNIQUE_SERIAL_NO`
                                from `intelligent_robot`.`uomp_qc_task_record`))));

