create view user_code_shift_name as
  select `a`.`ACCOUNT_CODE` AS `account_code`, `b`.`NAME` AS `NAME`, `c`.`VALUE` AS `skill`
  from ((`intelligent_robot`.`sys_account_info` `a` left join `intelligent_robot`.`emp_base_info` `b` on ((
    `a`.`EMP_CODE` = `b`.`CODE`))) left join `intelligent_robot`.`sys_dictionary_info` `c` on ((`a`.`SKILL_GROUP_CODE` =
                                                                                                `c`.`CODE`)))
  where (`c`.`CODE_PATH` = 'root/BusinessPara/UOMP/SkillGroup');

