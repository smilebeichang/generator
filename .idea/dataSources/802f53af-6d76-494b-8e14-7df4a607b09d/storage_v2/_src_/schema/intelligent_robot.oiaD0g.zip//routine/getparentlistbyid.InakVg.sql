create function getParentListById(id varchar(50))
  returns text
  BEGIN  
				#mysql向上递归查询所有的节点
        DECLARE str text;  
        DECLARE cid text;   
        DECLARE area_id_str text;
        select code into cid from kbms_dimensions_info where code = id;
        SET str = '';     
        SET area_id_str = null;
				SET SESSION group_concat_max_len=15120;
        WHILE cid is not null DO   
            SET str = concat(str, ',', cid);   
            SELECT group_concat(parent_code) INTO cid FROM kbms_dimensions_info where FIND_IN_SET(code, cid) > 0;   
        END WHILE; 
        select group_concat(code) into area_id_str from kbms_dimensions_info where find_in_set(code, str);
        RETURN area_id_str;   
    END;

