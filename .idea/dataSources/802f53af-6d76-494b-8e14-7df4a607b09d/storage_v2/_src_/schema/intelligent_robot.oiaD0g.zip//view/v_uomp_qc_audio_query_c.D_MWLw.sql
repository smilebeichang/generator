create view v_uomp_qc_audio_query_c as
  select `ws`.`SUM_NO`                                               AS `sum_no`,
         `ws`.`CONNECT_ID`                                           AS `connect_id`,
         `ws`.`CUST_NAME`                                            AS `cust_name`,
         `ws`.`CALL_NO`                                              AS `call_no`,
         `ws`.`CALL_TYPE`                                            AS `call_type`,
         `ws`.`ACCOUNT_CODE`                                         AS `account_code`,
         `ws`.`SERVICE_TYPE`                                         AS `service_type`,
         `ws`.`PARAM`                                                AS `PARAM`,
         str_to_date(`ws`.`TSPICKTIME`, '%Y%m%d%H%i%s')              AS `answer_date`,
         str_to_date(`ws`.`TSRINGTIME`, '%Y%m%d%H%i%s')              AS `call_date`,
         timestampdiff(SECOND, `ws`.`TSPICKTIME`, `ws`.`TSHANGTIME`) AS `talk_seconds`
  from `intelligent_robot`.`log_call_worksum_outer` `ws`
  where ((`ws`.`TSPICKTIME` is not null) and (`ws`.`PARAM` is not null) and (`ws`.`TSHANGTIME` is not null) and
         (`ws`.`ACCOUNT_CODE` is not null) and
         (not(`ws`.`CONNECT_ID` in (select `intelligent_robot`.`uomp_qc_task_record`.`UNIQUE_SERIAL_NO`
                                    from `intelligent_robot`.`uomp_qc_task_record`))));

